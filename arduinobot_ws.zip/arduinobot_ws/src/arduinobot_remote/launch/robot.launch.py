from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, SetEnvironmentVariable, ExecuteProcess
from launch.substitutions import Command, LaunchConfiguration
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory
import os
from os import pathsep


def generate_launch_description():

    # Arguments
    is_sim_arg = DeclareLaunchArgument('is_sim', default_value='True', description='Whether to launch in simulation mode')

    # Include launch files
    moveit_launch = ExecuteProcess(
        cmd=['gnome-terminal', '--', 'ros2', 'launch', 'arduinobot_moveit', 'moveit.launch.py'],
        output='screen'
    )

    gazebo_launch = ExecuteProcess(
        cmd=['gnome-terminal', '--', 'ros2', 'launch', 'arduinobot_description', 'gazebo.launch.py'],
        output='screen'
    )

    controller_launch = ExecuteProcess(
        cmd=['gnome-terminal', '--', 'ros2', 'launch', 'arduinobot_controller', 'controller.launch.py'],
        output='screen'
    )

    task_server_launch = ExecuteProcess(
        cmd=['gnome-terminal', '--', 'ros2', 'launch', 'arduinobot_remote', 'remote_interface.launch.py'],
        output='screen'
    )

    return LaunchDescription([
        is_sim_arg,
        moveit_launch,
        gazebo_launch,
        controller_launch,
        task_server_launch
    ])

